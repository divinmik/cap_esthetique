<?php



namespace App\Livewire\Dash;

use Livewire\Component;

class DashboardAdmin extends Component
{
    public function render()
    {
        dd('ok');
        return view('livewire.dash.dashboard-admin');
    }
}
