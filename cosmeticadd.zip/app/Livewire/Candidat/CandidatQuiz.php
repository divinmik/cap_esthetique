<?php

namespace App\Livewire\Candidat;

use Livewire\Component;

class CandidatQuiz extends Component
{
    public function render()
    {
        return view('livewire.candidat.candidat-quiz');
    }
}
