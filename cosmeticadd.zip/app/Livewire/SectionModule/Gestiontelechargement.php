<?php

namespace App\Livewire\SectionModule;

use Livewire\Component;

class Gestiontelechargement extends Component
{
    public function render()
    {
        return view('livewire.section-module.gestiontelechargement');
    }
}
