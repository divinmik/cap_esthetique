<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Facture_paiement extends Model
{
    //
}
