import './bootstrap';

//import Chart from 'chart.js/auto';
import Swal from 'sweetalert2';
window.Swal = Swal; // expose globalement

//import Alpine from 'alpinejs';
//window.Alpine = Alpine;
//Alpine.data('coursePlayer', (videos, currentIndexEntangle)=>({ /* ... */ }));
//Alpine.start();
