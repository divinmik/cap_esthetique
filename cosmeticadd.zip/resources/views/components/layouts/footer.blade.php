<footer class="footer">
    <div class="container-fluid">
        <div class="row align-items-center">
            
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                  
                </div>
            </div>
        </div>
    </div>
</footer>
