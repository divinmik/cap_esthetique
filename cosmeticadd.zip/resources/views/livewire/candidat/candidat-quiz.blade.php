<div
>
    <x-slot name="title_page">
        Quizs
    </x-slot>

    En maintenance 

</div>
