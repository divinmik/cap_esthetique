<?php

namespace App\Livewire\SectionModule;

use Livewire\Component;

class Gestionmodule extends Component
{
    public function render()
    {
        return view('livewire.section-module.gestionmodule');
    }
}
