<?php

namespace App\Livewire\Sectiondash;

use Livewire\Component;

class Modulecours extends Component
{
    public function render()
    {
        return view('livewire.sectiondash.modulecours');
    }
}
