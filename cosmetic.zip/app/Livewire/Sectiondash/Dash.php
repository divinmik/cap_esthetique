<?php

namespace App\Livewire\Sectiondash;

use Livewire\Component;

class Dash extends Component
{
    public function render()
    {
        return view('livewire.sectiondash.dash');
    }
}
