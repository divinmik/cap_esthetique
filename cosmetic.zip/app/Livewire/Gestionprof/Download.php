<?php

namespace App\Livewire\Gestionprof;

use Livewire\Component;

class Download extends Component
{
    public function render()
    {
        return view('livewire.gestionprof.download');
    }
}
