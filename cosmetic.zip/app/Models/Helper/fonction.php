<?php

namespace App\Models\Helper;

use Illuminate\Database\Eloquent\Model;

class fonction extends Model
{
    //
}
